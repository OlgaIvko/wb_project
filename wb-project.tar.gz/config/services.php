<?php

return [
    'wildberries' => [
        'base_url' => env('WB_API_BASE_URL', 'http://109.73.206.144:6969'),
        'key' => env('WB_API_KEY', 'E6kUTYrYwZq2tN4QEtyzsbEBk3ie'),
    ],
];
